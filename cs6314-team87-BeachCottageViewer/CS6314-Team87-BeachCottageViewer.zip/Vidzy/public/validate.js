window.onload = function(){

    //there will be one span element for each input field
    // when the page is loaded, we create them and append them to corresponding input elements 
	// they are initially empty and hidden
    var password=document.getElementById("pwd")
    var span1 = document.createElement("span");
    var error=false
	span1.style.display = "none"; //hide the span element
    password.parentNode.appendChild(span1);

    password.onfocus=function(){
        if(error==false){
            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Passwords must have at least 6 characters,1 uppercase, and one special character";
        }

    }
    password.onblur = function(){
        span1.style.display='none';
        password.classList='form-control'

    }
    
    var form = document.getElementById("regform");
    form.onsubmit = function(e){
        var passvalidvar1=passvalid()
        console.log(passvalidvar1)
        if(passvalidvar1==true){
        }
        else{
            e.preventDefault();
            let passvalidvar=document.getElementById("pwd").classList=('error')
            

        }
        


    	//e.preventDefault();

    }
    function passvalid(){
        console.log("validating");
        let passvalidvar=document.getElementById("pwd").value
        var tooshort=false
        var nonumbers=false
        var noup=false
        var nolower=false
        var nospecial=false
        var confirmwrong=true
        if(passvalidvar.length<6){
            tooshort=true;
            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Error:password must be at least 6 characters";
            return false;
        }
        else if(passvalidvar.search(/[0-9]/)==-1){
            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Error:password has no numbers";
            return false
        }
        else if(passvalidvar.search(/[A-Z]/)==-1){
            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Error:password has no uppercase letters";
            return false
        }
        else if(passvalidvar.search(/[a-z]/)==-1){

            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Error:password has no lowercase letters";
            return false
        }
        else if(passvalidvar.search(/[!\@\#\$\%\^\&\*\+]/)==-1){
            password.parentNode.appendChild(span1);
            span1.style.display='inline';
            span1.innerHTML="Error:password has no special characters";
            return false
        }
        else{
            return true
        }

    }


}

