$(function(){
$.ajax({
	method:'GET',
	url:'api/videos',

	success: function(videos){
		$.each(videos,function(i, video){
			//$('#videolist').append('<li style="list-style-type:none; float:left; padding: 16px"> <img src="../images/'+video.image+'"style="width: 200px; height:200px"><br>'+video.title + '</li>');
			$('#videolist').append('<li>'+video.title + '</li>');


		});


	},
	error:function(){
		alert('Cannot Load Videos');
	}

});
	$("#add").click(function(){

		var ntitle=$('#title').val();
		var ngenre=$('#genre').val();
		var ndesc=$('#desc').val();

		var nvid={
			title:ntitle,
			genre:ngenre,
			desc:ndesc
		}
		alert('nvid made');
		$.ajax({
		method:'POST',
		url:'api/videos',
		data:nvid,
		success: function(nvideo){
			alert("button clicked");
			$('#videolist').append('<li>'+nvideo.title + '</li>');

		},
		error:function(){
			alert('Error loading videos');
		}

	});
		

	});

});

