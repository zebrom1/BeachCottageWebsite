var express = require('express');
var router = express.Router();

var monk=require('monk');

var db=monk('localhost:27017/beachcottage');



	var collection=db.get('cottages');




// api/videos
router.get('/', function(req, res) {
	collection.find({},function(err, videos){
		if(err) throw err;
		res.json(videos);
	});
  //res.render('index', { title: 'Express' });
});


router.get('/:id', (req, res) => {
    const collection = db.get('cottages');
    collection.findOne({ _id: req.params.id })
    .then(video => res.json(video))
    .catch(err => res.send({ error: err.message }))
});

//add new video
router.post('/',function(req,res){

	collection.insert({
		title:req.body.title,
		genre:req.body.genre,
		description:req.body.desc
	},
	function(err, videos){
		if(err) throw err;
		res.json(videos);
	});
});
//update
router.put('/:id',function(req,res){
collection.update({_id: req.params.id},
		{ $set: {
		title:req.body.title,
		genre:req.body.genre,
		description:req.body.desc
	}},
	function(err, videos){
		if(err) throw err;
		res.json(videos);
	});
});

router.delete('/:id', (req, res) => {
    const collection = db.get('videos');
    collection.remove({ _id: req.params.id },
    	function(err, videos){
		if(err) throw err;
		res.json(videos);
	});
});

module.exports = router;
