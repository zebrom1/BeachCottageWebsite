var express = require('express');
var router = express.Router();

var monk = require('monk');

var db = monk('localhost:27017/beachcottage');
var passport = require('passport');
var Account = require('../models/account');




// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

router.get('/', function(req, res, next) {
  res.redirect('/cottages');
});
router.get('/register', function(req, res) {
    res.render('register');
});
router.get('/login', function(req, res) {
    res.render('login', {user:req.user});
});
router.get('/loginerror', function(req, res) {
    res.render('loginerror', {user:req.user});
});
router.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
});

router.get('/cottages/new', (req, res) => {
  res.render('new',{ user:req.user});
});
router.get('/cottages', function(req, res) {
  console.log(req.user);
  var collection = db.get('cottages');
  collection.find({avalability:true }, function(err, videos){
    if (err) throw err;
    res.render('index', { user:req.user,videos});
  });
});

router.get('/cottagesadmin', function(req, res) {
  console.log(req.user);
  var collection = db.get('cottages');
  collection.find({}, function(err, videos){
    if (err) throw err;
    res.render('index', { user:req.user,videos});
  });
});



router.get('/:id', (req, res) => {
  const collection = db.get('cottages');
  collection.findOne({ _id: req.params.id }, (err, video) => {
    (err) ? res.send({ error: err.message }) : res.render('show', {video});
  })
});

router.get('/cottages/:id/edit', (req, res) => {
  const collection = db.get('cottages');
  collection.findOne({ _id: req.params.id })
  .then(video => res.render('edit', { video: video, user:req.user }))
  .catch(err => res.send({ error: err.message }))
});

router.get('/cottages/:id', (req, res) => {
  console.log(req.params.id);
  const collection = db.get('cottages');
  collection.findOne({ _id: req.params.id })
  .then(video => res.render('show', { video , user:req.user  }))
  .catch(err => res.send({ error: err.message }))
});
router.post('/register', function(req, res) {
  console.log("entering register post")
  Account.register(new Account({ username : req.body.username,isadmin:false,favorites:[]  }), req.body.password, function(err, account) {
      if (err) {
          console.log(err);
          return res.render('register', { account : account });
      }

      passport.authenticate('local')(req, res, function () {
        res.redirect('/');
      });
  });
});

router.post('/favorites',(req,res) =>{
  console.log(req.user.favorites[0]);
  const collection = db.get('cottages');
    collection.find({ _id: { $in:[req.user.favorites[0],req.user.favorites[1],req.user.favorites[2],req.user.favorites[3],req.user.favorites[4],req.user.favorites[5],req.user.favorites[6],req.user.favorites[7],req.user.favorites[8],req.user.favorites[9]]}, avalability:true})
    .then(videos => res.render('index', { user:req.user,videos }))
  });
router.post('/cottages/:id/addfavorite', (req,res) =>{
  const collection = db.get('accounts');
  console.log(req.params.id);
  console.log(req.user.favorites);
  console.log(req.user.id);
  req.user.favorites.push(req.params.id);
   collection.update({
    _id: req.user.id, 
  }, { $set: {
    favorites:req.user.favorites,
  }})
  res.redirect('/');
});

router.post('/cottages/:id/removefavorite', (req,res) =>{
  const collection = db.get('accounts');
  var newfavorites=[];
  console.log(req.params.id);
  console.log(req.user.favorites);
  console.log(req.user.id);
  req.user.favorites.forEach(curritem =>{
    if(curritem!=req.params.id){
      newfavorites.push(curritem);
      console.log(newfavorites);
    }
  });
  
   collection.update({
    _id: req.user.id, 
  }, { $set: {
    favorites:newfavorites,
  }})
  res.redirect('/');
});

router.post('/login', passport.authenticate('local',{successRedirect: '/',failureRedirect: '/loginerror'}), function(req, res) {
  console.log(req.body.username);
  console.log(req.body.password);
});

router.post('/searchCottageName', (req, res) => {
  console.log(req.body.cottageName)
  console.log(req.body.numOfBeds)
  const searchCottages = new RegExp(req.body.cottageName);
  const searchBeds = req.body.numOfBeds;
  const collection = db.get('cottages');
  if(searchBeds==""){
    console.log("only searching")
    collection.find({ cottageName: searchCottages,avalability:true})
    .then(videos => res.render('index', { user:req.user,videos }))
    .catch(err => res.send({ error: err.message }))
  }
  else if(searchCottages==""){
    console.log("only filtering")
    collection.find({ numOfBeds:searchBeds,avalability:true})
    .then(videos => res.render('index', { user:req.user,videos }))
    .catch(err => res.send({ error: err.message }))
  }
  else{
  console.log("searching and filtering")
  collection.find({ cottageName: searchCottages, numOfBeds:searchBeds,avalability:true})
  .then(videos => res.render('index', { user:req.user,videos }))
  .catch(err => res.send({ error: err.message }))
};
});

router.post('/filterCottageBeds', (req, res) => {
  const collection = db.get('cottages');
  console.log(req.body.numOfBeds);
  collection.find({ numOfBeds: req.body.numOfBeds })
  .then(videos => res.render('index', { videos }))
  .catch(err => res.send({ error: err.message }));
});
router.post('/cottages', (req, res) => {
  const collection = db.get('cottages');
  collection.insert({
    cottageName:req.body.cottageName,
    numOfBeds:req.body.numOfBeds,
    numOfBaths:req.body.numOfBaths,
    reservation:{},
    price:req.body.price,
    description:req.body.desc,
    image:req.body.image,
    avalability:true,
    contact:req.body.contact
  })
  .then(() => res.redirect('/cottages'))
  .catch(err => res.send({ error: err.message }))
});


router.delete('/cottages/:id', (req, res) => {
  const collection = db.get('cottages');
  collection.update({
    _id: req.params.id, 
  }, { $set: {
    avalability:false,

 }}) .then(result => {
    console.log('hello after');
    return (result.n === 0) ? res.status(404).send({ error: 'Cottage does not exist' })
                : res.redirect('/cottages');
  })
});

router.patch('/cottages/:id', (req, res) => {
  console.log('hello before');
  const collection = db.get('cottages');
  collection.update({
    _id: req.params.id, 
  }, { $set: {
    cottageName:req.body.cottageName,
    numOfBeds:req.body.numOfBeds,
    numOfBaths:req.body.numOfBaths,
    reservation:req.body.reservation,
    price:req.body.price,
    description:req.body.desc,
    image:req.body.image,
    contact:req.body.contact
  }})
  .then(result => {
    console.log('hello after');
    return (result.n === 0) ? res.status(404).send({ error: 'Cottage does not exist' })
                : res.redirect('/cottages');
  })
  .catch(err => res.send({ error: err.message }));
});

//adding a cottage to the cart


module.exports = router;
